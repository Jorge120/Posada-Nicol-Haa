﻿Imports MySql.Data.MySqlClient

Module Cod

    Public Function Autocompletar(ByVal sql As String, ByVal campo As String) As AutoCompleteStringCollection
        Dim RsAuto As New DataTable
        Dim autocompletado As New AutoCompleteStringCollection
        RsAuto = SQLCOMBO(sql)

        For Each DataRow In RsAuto.Rows
            autocompletado.Add(Convert.ToString(DataRow(campo)))
        Next
        Return autocompletado
    End Function

    Public Sub completar(ByRef combo As ComboBox, ByVal sql As String, ByVal PK As String, ByVal valor As String, ByVal campo As String)
        combo.DataSource = SQLCOMBO(sql)
        combo.ValueMember = PK
        combo.DisplayMember = valor

        combo.AutoCompleteCustomSource = Autocompletar(sql, campo)
        combo.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        combo.AutoCompleteSource = AutoCompleteSource.CustomSource

    End Sub

    Public Sub completar(ByRef CajaTexto As TextBox, ByVal sql As String, ByVal campo As String)

        CajaTexto.AutoCompleteCustomSource = Autocompletar(sql, campo)
        CajaTexto.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        CajaTexto.AutoCompleteSource = AutoCompleteSource.CustomSource
    End Sub


End Module
