﻿Module Bitacora
    Public users As String
    Public Sub bitac(evento As String)
        Dim insert As String = ""

        insert = "INSERT INTO Bitacora(fecha,login,operacion,hora) values ('" & Format(Now.Date, "yyyy-MM-dd") & "','" & users & "','" & evento & "','" & Format(TimeOfDay, "hh:mm:ss tt") & "')"
        SQLIDU(insert)
    End Sub

End Module
