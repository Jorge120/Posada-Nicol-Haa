﻿
Imports MySql.Data.MySqlClient

Module SQLADMIN

    'Public srv As String = My.Settings.Servidor    '"192.168.26.250" 'localhost
    Public srv As String = "localhost"
    Public user As String = "root"
    Public port As String = "3306"
    Public bd As String = "administracion" '"biblio"
    Public pass As String = "admin"
    Public conex As New MySqlConnection

    'Este procedimiento intenta establecer una conneccion a una base de datos sql
    Public Sub conectar()
        Try
            conex.Close()
            conex.ConnectionString = "server=" & "localhost; port=3306" & ";user=" & "root" & ";password=admin" & ";database=" & bd
            conex.Open()
            'MsgBox("conexion exitosa")
        Catch ex As MySqlException
            MsgBox(ex.Message & ex.Number)
            'If ex.Number = 1042 Then
            MsgBox("No se puede conectar con el servidor" & vbCrLf & "Actualice los datos")
            'FrmDatosServidor.Show()
            'FrmLogin.Close()
            'End If
        End Try
    End Sub


    Public Sub SQLIDU(ByVal Sql As String)
        Try
            conectar()
            Dim comando As New MySqlCommand(Sql, conex)
            comando.ExecuteNonQuery()
            'Se utiliza NonQuery porque el sql no devuelve un resultado
            conex.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub
    Public Sub DBInsert(ByVal Tabla As String, ByVal campval() As String)
        Try
            'conectar()
            Dim strinsert As String = "INSERT INTO " & Tabla & "("
            Dim contCampos As Integer = 0

            'Rutina para obtener los campos del vector enviado
            Dim campos As String = ""
            For i As Integer = 0 To (campval.Length - 1) Step 2
                campos = campos & campval(i) & ","
                contCampos += 1
            Next
            'Elimina la ultima coma
            campos = Left(campos, campos.Length - 1)


            'Rutina para obtener los valores de campo del vector enviado
            Dim valores As String = ""
            Dim ContValores As Integer = 0

            For i As Integer = 1 To (campval.Length - 1) Step 2
                valores = valores & campval(i) & ","
                ContValores += 1
            Next
            'Elimina la ultima coma
            valores = Left(valores, valores.Length - 1)


            strinsert = strinsert & campos & ") VALUES("
            strinsert = strinsert & valores & ")"

            If contCampos = ContValores Then
                MsgBox(strinsert)
            Else
                MsgBox("El numero de campos no coincide con el número de valores")

            End If



        Catch ex As Exception
            MsgBox(ex.Message)
        End Try


    End Sub

    Public Function SQLSEL(ByVal sql As String) As DataSet
        Try
            conectar()

            Dim Adaptador As New MySqlDataAdapter(sql, conex)
            Dim RsDatos As New DataSet
            Adaptador.Fill(RsDatos, "datos")
            Return (RsDatos)
            conex.Close()

        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    Public Function SQLCOMBO(ByVal sql As String) As DataTable

        Try
            conectar()
            Dim Adap As New MySqlDataAdapter(sql, conex)
            Dim DT As New DataTable
            Adap.Fill(DT)
            Return DT
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function

    Public Function SQLREADER(ByVal sql) As MySqlDataReader
        Try
            conectar()
            Dim comando As New MySqlCommand(sql, conex)
            Dim Dr As MySqlDataReader
            Dr = comando.ExecuteReader()
            Return Dr
            conex.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Function
End Module


