﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPreRegistro
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPreRegistro))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DgvRegistro = New System.Windows.Forms.DataGridView()
        Me.BtnCerrar = New System.Windows.Forms.Button()
        Me.Nombre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApellidoP = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ApellidoM = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Correo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Telefono = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Habitacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DgvRegistro, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(374, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(167, 30)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Pre-Registros"
        '
        'DgvRegistro
        '
        Me.DgvRegistro.BackgroundColor = System.Drawing.Color.White
        Me.DgvRegistro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvRegistro.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Nombre, Me.ApellidoP, Me.ApellidoM, Me.Correo, Me.Telefono, Me.Habitacion})
        Me.DgvRegistro.Location = New System.Drawing.Point(26, 54)
        Me.DgvRegistro.Name = "DgvRegistro"
        Me.DgvRegistro.Size = New System.Drawing.Size(945, 436)
        Me.DgvRegistro.TabIndex = 1
        '
        'BtnCerrar
        '
        Me.BtnCerrar.BackColor = System.Drawing.Color.White
        Me.BtnCerrar.BackgroundImage = CType(resources.GetObject("BtnCerrar.BackgroundImage"), System.Drawing.Image)
        Me.BtnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCerrar.Location = New System.Drawing.Point(920, 9)
        Me.BtnCerrar.Name = "BtnCerrar"
        Me.BtnCerrar.Size = New System.Drawing.Size(51, 34)
        Me.BtnCerrar.TabIndex = 34
        Me.BtnCerrar.UseVisualStyleBackColor = False
        '
        'Nombre
        '
        Me.Nombre.DataPropertyName = "Nombre"
        Me.Nombre.HeaderText = "Nombre"
        Me.Nombre.Name = "Nombre"
        Me.Nombre.Width = 150
        '
        'ApellidoP
        '
        Me.ApellidoP.DataPropertyName = "ApellidoP"
        Me.ApellidoP.HeaderText = "ApellidoP"
        Me.ApellidoP.Name = "ApellidoP"
        Me.ApellidoP.Width = 150
        '
        'ApellidoM
        '
        Me.ApellidoM.DataPropertyName = "ApellidoM"
        Me.ApellidoM.HeaderText = "ApellidoM"
        Me.ApellidoM.Name = "ApellidoM"
        Me.ApellidoM.Width = 150
        '
        'Correo
        '
        Me.Correo.DataPropertyName = "Correo"
        Me.Correo.HeaderText = "Correo"
        Me.Correo.Name = "Correo"
        Me.Correo.Width = 150
        '
        'Telefono
        '
        Me.Telefono.DataPropertyName = "Telefono"
        Me.Telefono.HeaderText = "Telefono"
        Me.Telefono.Name = "Telefono"
        Me.Telefono.Width = 150
        '
        'Habitacion
        '
        Me.Habitacion.DataPropertyName = "Habitacion"
        Me.Habitacion.HeaderText = "Habitacion"
        Me.Habitacion.Name = "Habitacion"
        Me.Habitacion.Width = 150
        '
        'FrmPreRegistro
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(988, 511)
        Me.Controls.Add(Me.BtnCerrar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.DgvRegistro)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FrmPreRegistro"
        Me.Text = "FrmPreRegistro"
        CType(Me.DgvRegistro, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents DgvRegistro As System.Windows.Forms.DataGridView
    Friend WithEvents BtnCerrar As System.Windows.Forms.Button
    Friend WithEvents Nombre As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ApellidoP As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ApellidoM As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Correo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Telefono As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Habitacion As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
