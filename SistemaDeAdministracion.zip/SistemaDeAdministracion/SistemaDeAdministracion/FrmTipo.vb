﻿Public Class FrmTipo

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvTipo.CellContentClick

    End Sub

    Private Sub DgvTipo_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvTipo.CellContentDoubleClick

    End Sub

    Private Sub FrmTipo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GbxHabilitar.Visible = True
        DgvTipo.DataSource = SQLSEL("Select * from habitacion").Tables("datos").DefaultView

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GbxHabilitar.Enter

    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub
End Class