﻿Public Class FrmPreRegistro

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvRegistro.CellContentClick

    End Sub

    Private Sub FrmPreRegistro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DgvRegistro.DataSource = SQLSEL("Select Nombre, ApellidoP, ApellidoM, Correo, Telefono, Habitacion from registro").Tables("datos").DefaultView

    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub
End Class
