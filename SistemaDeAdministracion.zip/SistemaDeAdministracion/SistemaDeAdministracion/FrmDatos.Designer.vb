﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDatos
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmDatos))
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CmbTipo = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.BtnResul = New System.Windows.Forms.Button()
        Me.TxtRes = New System.Windows.Forms.TextBox()
        Me.TxtPrecio = New System.Windows.Forms.TextBox()
        Me.TxtNu = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TxtDias = New System.Windows.Forms.TextBox()
        Me.DtpFecha = New System.Windows.Forms.DateTimePicker()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Txtentrada = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Txttelefono = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Txtcorreo = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Txtnombrec = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.DgvTipo = New System.Windows.Forms.DataGridView()
        Me.IdHaibtacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NoHabitacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Verificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BtnCerrar = New System.Windows.Forms.Button()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DgvTipo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(56, 515)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(375, 100)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 29)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(160, 50)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Pre-Registro"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(188, 29)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(160, 50)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Guardar"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CmbTipo)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.BtnResul)
        Me.GroupBox1.Controls.Add(Me.TxtRes)
        Me.GroupBox1.Controls.Add(Me.TxtPrecio)
        Me.GroupBox1.Controls.Add(Me.TxtNu)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.TxtDias)
        Me.GroupBox1.Controls.Add(Me.DtpFecha)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Txtentrada)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Txttelefono)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Txtcorreo)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Txtnombrec)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 44)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(855, 331)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        '
        'CmbTipo
        '
        Me.CmbTipo.BackColor = System.Drawing.Color.White
        Me.CmbTipo.FormattingEnabled = True
        Me.CmbTipo.Items.AddRange(New Object() {"Sencilla", "Doble"})
        Me.CmbTipo.Location = New System.Drawing.Point(632, 22)
        Me.CmbTipo.Name = "CmbTipo"
        Me.CmbTipo.Size = New System.Drawing.Size(200, 27)
        Me.CmbTipo.TabIndex = 7
        Me.CmbTipo.Text = "Elija una habitacion"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(438, 184)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(115, 22)
        Me.Label11.TabIndex = 50
        Me.Label11.Text = "Precio total"
        '
        'BtnResul
        '
        Me.BtnResul.Location = New System.Drawing.Point(632, 219)
        Me.BtnResul.Name = "BtnResul"
        Me.BtnResul.Size = New System.Drawing.Size(154, 39)
        Me.BtnResul.TabIndex = 11
        Me.BtnResul.Text = " Calcular Precio"
        Me.BtnResul.UseVisualStyleBackColor = True
        '
        'TxtRes
        '
        Me.TxtRes.Location = New System.Drawing.Point(632, 180)
        Me.TxtRes.Name = "TxtRes"
        Me.TxtRes.Size = New System.Drawing.Size(200, 26)
        Me.TxtRes.TabIndex = 10
        '
        'TxtPrecio
        '
        Me.TxtPrecio.Location = New System.Drawing.Point(632, 126)
        Me.TxtPrecio.Name = "TxtPrecio"
        Me.TxtPrecio.Size = New System.Drawing.Size(200, 26)
        Me.TxtPrecio.TabIndex = 9
        '
        'TxtNu
        '
        Me.TxtNu.Location = New System.Drawing.Point(632, 72)
        Me.TxtNu.Name = "TxtNu"
        Me.TxtNu.Size = New System.Drawing.Size(200, 26)
        Me.TxtNu.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(438, 130)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 22)
        Me.Label2.TabIndex = 45
        Me.Label2.Text = "Precio"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(438, 79)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(170, 22)
        Me.Label8.TabIndex = 44
        Me.Label8.Text = "No. de habitacion"
        '
        'TxtDias
        '
        Me.TxtDias.BackColor = System.Drawing.Color.White
        Me.TxtDias.Location = New System.Drawing.Point(219, 229)
        Me.TxtDias.Multiline = True
        Me.TxtDias.Name = "TxtDias"
        Me.TxtDias.Size = New System.Drawing.Size(200, 29)
        Me.TxtDias.TabIndex = 5
        '
        'DtpFecha
        '
        Me.DtpFecha.Location = New System.Drawing.Point(219, 184)
        Me.DtpFecha.Name = "DtpFecha"
        Me.DtpFecha.Size = New System.Drawing.Size(200, 26)
        Me.DtpFecha.TabIndex = 4
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(438, 27)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 22)
        Me.Label9.TabIndex = 37
        Me.Label9.Text = "Habitacion"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 236)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(182, 22)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "Dias de Hospedaje"
        '
        'Txtentrada
        '
        Me.Txtentrada.BackColor = System.Drawing.Color.White
        Me.Txtentrada.Location = New System.Drawing.Point(219, 287)
        Me.Txtentrada.Multiline = True
        Me.Txtentrada.Name = "Txtentrada"
        Me.Txtentrada.Size = New System.Drawing.Size(200, 29)
        Me.Txtentrada.TabIndex = 6
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(20, 294)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(158, 22)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Hora de entrada"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(20, 184)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(173, 22)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "Fecha de Entrada"
        '
        'Txttelefono
        '
        Me.Txttelefono.BackColor = System.Drawing.Color.White
        Me.Txttelefono.Location = New System.Drawing.Point(219, 130)
        Me.Txttelefono.Multiline = True
        Me.Txttelefono.Name = "Txttelefono"
        Me.Txttelefono.Size = New System.Drawing.Size(200, 29)
        Me.Txttelefono.TabIndex = 3
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(20, 130)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(91, 22)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Telefono"
        '
        'Txtcorreo
        '
        Me.Txtcorreo.BackColor = System.Drawing.Color.White
        Me.Txtcorreo.Location = New System.Drawing.Point(219, 72)
        Me.Txtcorreo.Multiline = True
        Me.Txtcorreo.Name = "Txtcorreo"
        Me.Txtcorreo.Size = New System.Drawing.Size(200, 29)
        Me.Txtcorreo.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(20, 79)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(75, 22)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Correo"
        '
        'Txtnombrec
        '
        Me.Txtnombrec.BackColor = System.Drawing.Color.White
        Me.Txtnombrec.Location = New System.Drawing.Point(219, 29)
        Me.Txtnombrec.Multiline = True
        Me.Txtnombrec.Name = "Txtnombrec"
        Me.Txtnombrec.Size = New System.Drawing.Size(200, 29)
        Me.Txtnombrec.TabIndex = 1
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(20, 29)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(177, 22)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Nombre Completo"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(322, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(245, 30)
        Me.Label10.TabIndex = 34
        Me.Label10.Text = "Registro de Clientes"
        '
        'DgvTipo
        '
        Me.DgvTipo.BackgroundColor = System.Drawing.Color.White
        Me.DgvTipo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvTipo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IdHaibtacion, Me.NoHabitacion, Me.Tipo, Me.Verificacion})
        Me.DgvTipo.Location = New System.Drawing.Point(57, 381)
        Me.DgvTipo.Name = "DgvTipo"
        Me.DgvTipo.Size = New System.Drawing.Size(732, 128)
        Me.DgvTipo.TabIndex = 35
        '
        'IdHaibtacion
        '
        Me.IdHaibtacion.DataPropertyName = "IdHabitacion"
        Me.IdHaibtacion.FillWeight = 200.0!
        Me.IdHaibtacion.HeaderText = "Id Habitacion"
        Me.IdHaibtacion.Name = "IdHaibtacion"
        Me.IdHaibtacion.Visible = False
        Me.IdHaibtacion.Width = 200
        '
        'NoHabitacion
        '
        Me.NoHabitacion.DataPropertyName = "NoHabitacion"
        Me.NoHabitacion.HeaderText = "Numero de Habitacion"
        Me.NoHabitacion.Name = "NoHabitacion"
        Me.NoHabitacion.Width = 230
        '
        'Tipo
        '
        Me.Tipo.DataPropertyName = "Tipo"
        Me.Tipo.HeaderText = "Tipo de Habitacion"
        Me.Tipo.Name = "Tipo"
        Me.Tipo.Width = 230
        '
        'Verificacion
        '
        Me.Verificacion.DataPropertyName = "Verificacion"
        Me.Verificacion.HeaderText = "Verificacion"
        Me.Verificacion.Name = "Verificacion"
        Me.Verificacion.Width = 230
        '
        'BtnCerrar
        '
        Me.BtnCerrar.BackColor = System.Drawing.Color.White
        Me.BtnCerrar.BackgroundImage = CType(resources.GetObject("BtnCerrar.BackgroundImage"), System.Drawing.Image)
        Me.BtnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCerrar.Location = New System.Drawing.Point(813, 8)
        Me.BtnCerrar.Name = "BtnCerrar"
        Me.BtnCerrar.Size = New System.Drawing.Size(51, 34)
        Me.BtnCerrar.TabIndex = 33
        Me.BtnCerrar.UseVisualStyleBackColor = False
        '
        'FrmDatos
        '
        Me.AcceptButton = Me.BtnResul
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.BtnCerrar
        Me.ClientSize = New System.Drawing.Size(881, 631)
        Me.Controls.Add(Me.DgvTipo)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.BtnCerrar)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FrmDatos"
        Me.Text = "FrmDatos"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DgvTipo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Txtentrada As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Txttelefono As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Txtcorreo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Txtnombrec As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents DtpFecha As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TxtDias As System.Windows.Forms.TextBox
    Friend WithEvents BtnCerrar As System.Windows.Forms.Button
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TxtPrecio As System.Windows.Forms.TextBox
    Friend WithEvents TxtNu As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents BtnResul As System.Windows.Forms.Button
    Friend WithEvents TxtRes As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents CmbTipo As System.Windows.Forms.ComboBox
    Friend WithEvents DgvTipo As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents IdHaibtacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoHabitacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Verificacion As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
