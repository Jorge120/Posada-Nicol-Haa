﻿Imports System.Data.SqlClient

Public Class FrmCorteCaja

    Private Property cadena As String

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        Dim fecha As Date

        'fecha almacenara la fecha del sistema

        Dim importe As Integer

        'importe guardara el total del arqueo

        fecha = Now.Date.ToShortDateString
        'convertimos la fecha enn un formato corto dd/mm/aaaa

        Dim con As New SqlConnection(cadena) 'creamos la consulta

        Dim com As New SqlCommand("select sum(Total) from [reservacion] where fecha ='" & fecha & "‘", con)

        Try
            con.Open()

            importe = CInt(com.ExecuteScalar()) 'asignamos el valor del importe

            con.Close()

        Catch ex As Exception

        End Try

        MsgBox("" & importe) 'mostramos el importe
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub

    Private Sub FrmCorteCaja_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class