﻿Imports MySql.Data.MySqlClient
Public Class frmLogin


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Se llena los datos 
    'Funcionalidad: Confirma los datos insetados
    'Fecha: 2/02/2017
    'Salida: *
    Private Sub btnaceptar_Click(sender As Object, e As EventArgs) Handles btnaceptar.Click
        Dim user As MySqlDataReader

        Dim consulta As String = ""

        consulta = "SELECT *" & _
                   " FROM login" & _
                   " WHERE IdLogin='" & cmbUsers.Text & "'"
        'Pruebo la consulta, para verificar si se construye
        'Adecuadamente
        'MsgBox(consulta)
        user = SQLREADER(consulta)
        'Lee el primer registro
        Dim pasw As String = ""
        Dim usuario As String = ""
        'Recorremos el dataReader
        While user.Read
            pasw = user("pass")
            usuario = user("Nombre")
        End While
        'Revisamos si la consulta tuvo resultados
        If user.HasRows Then 'El registro si existe
            If Txtpasw.Text = pasw Then
                MsgBox("BIENVENIDO: " & usuario)
                'Muestra el formulario principal
                Me.Hide()
                FrmMenu.Show()
                'Cierra el login
            Else
                MsgBox("La contraseña es incorrecto")
            End If
        Else
            MsgBox("El usuario no existe", vbCritical, "Annet")
        End If
        Txtpasw.Clear()
        bitac("Inicio de la Sesion")
    End Sub

    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparece al inicio los usuarios solicitados, la hora y la fecha
    'Funcionalidad: Registra la hora, la fecha y el usuario, que accedio 
    'Fecha: 2/02/2017
    'Salida: *
    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        completar(cmbUsers, "SELECT * FROM Login", "IdLogin", "IdLogin", "IdLogin")
        lblFecha.Text = DateTime.Now.ToString("dd/MM/yyyy")
        lblHora.Text = Date.Now.ToString("hh:mm:ss")

    End Sub
   

    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Sale del formulario y regresa a la bienvenida
    'Funcionalidad: Cierra el formulario y aparece la opcionm, diciendo: si esta segura de salir
    'Fecha: 2/02/2017
    'Salida: *
    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        Dim Respuesta As Object

        Respuesta = MsgBox("¿Esta Seguro que quiere salir?", vbCritical + MsgBoxStyle.YesNo, "")
        If Respuesta = vbYes Then
            Me.Hide()
            frmBienvenida.Show()
            End
        ElseIf Respuesta = vbNo Then
        End If
    End Sub
End Class