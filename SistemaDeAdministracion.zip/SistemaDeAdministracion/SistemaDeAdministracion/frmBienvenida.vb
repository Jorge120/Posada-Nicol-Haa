﻿Public Class frmBienvenida


    'Autor: Annet Anay Pool Can
    'Entrada: Aparece la opción de cerrar sesión
    'Funcionalidad: Cierra el sistema completo
    'Fecha: 5/03/2017
    'Salida: *
    Private Sub BtnCancelar_Click(sender As Object, e As EventArgs) Handles BtnCancelar.Click
        Me.Close()
    End Sub


    'Autor: Annet Anay Pool Can
    'Entrada: Aparecen dos opciones, escoge la segunda opción
    'Funcionalidad: Llama al formulario datos(operador)
    'Fecha: 5/03/2017
    'Salida: *
    Private Sub btnoperador_Click(sender As Object, e As EventArgs) Handles btnoperador.Click
        FrmDatos.Show()
    End Sub


    'Autor: Annet Anay Pool Can
    'Entrada: Aparecen dos opciones, escoge la segunda opción
    'Funcionalidad: Llama al formulario login 
    'Fecha: 5/03/2017
    'Salida: *
    Private Sub btnadmin_Click(sender As Object, e As EventArgs) Handles btnadmin.Click
        frmLogin.Show()
    End Sub

    Private Sub frmBienvenida_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
