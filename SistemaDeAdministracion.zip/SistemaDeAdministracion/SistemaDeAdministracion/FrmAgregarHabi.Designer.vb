﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAgregarHabi
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmAgregarHabi))
        Me.GbxHabilitar = New System.Windows.Forms.GroupBox()
        Me.BtnEliminar = New System.Windows.Forms.Button()
        Me.BtnAgregar = New System.Windows.Forms.Button()
        Me.BtnEditar = New System.Windows.Forms.Button()
        Me.DgvTipo = New System.Windows.Forms.DataGridView()
        Me.IdHaibtacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NoHabitacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Tipo = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Verificacion = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Precio = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Estacionamiento = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.TxtNu = New System.Windows.Forms.TextBox()
        Me.TxtPrecio = New System.Windows.Forms.TextBox()
        Me.CmbSiNo = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.CmbVerificacion = New System.Windows.Forms.ComboBox()
        Me.CmbTipo = New System.Windows.Forms.ComboBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnCerrar = New System.Windows.Forms.Button()
        Me.GbxHabilitar.SuspendLayout()
        CType(Me.DgvTipo, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GbxHabilitar
        '
        Me.GbxHabilitar.Controls.Add(Me.BtnEliminar)
        Me.GbxHabilitar.Controls.Add(Me.BtnAgregar)
        Me.GbxHabilitar.Controls.Add(Me.BtnEditar)
        Me.GbxHabilitar.Location = New System.Drawing.Point(29, 455)
        Me.GbxHabilitar.Name = "GbxHabilitar"
        Me.GbxHabilitar.Size = New System.Drawing.Size(579, 76)
        Me.GbxHabilitar.TabIndex = 3
        Me.GbxHabilitar.TabStop = False
        '
        'BtnEliminar
        '
        Me.BtnEliminar.BackColor = System.Drawing.Color.White
        Me.BtnEliminar.Location = New System.Drawing.Point(393, 19)
        Me.BtnEliminar.Name = "BtnEliminar"
        Me.BtnEliminar.Size = New System.Drawing.Size(164, 44)
        Me.BtnEliminar.TabIndex = 8
        Me.BtnEliminar.Text = "Eliminar"
        Me.BtnEliminar.UseVisualStyleBackColor = False
        '
        'BtnAgregar
        '
        Me.BtnAgregar.BackColor = System.Drawing.Color.White
        Me.BtnAgregar.Location = New System.Drawing.Point(6, 19)
        Me.BtnAgregar.Name = "BtnAgregar"
        Me.BtnAgregar.Size = New System.Drawing.Size(164, 44)
        Me.BtnAgregar.TabIndex = 6
        Me.BtnAgregar.Text = "Agregar"
        Me.BtnAgregar.UseVisualStyleBackColor = False
        '
        'BtnEditar
        '
        Me.BtnEditar.BackColor = System.Drawing.Color.White
        Me.BtnEditar.Location = New System.Drawing.Point(193, 19)
        Me.BtnEditar.Name = "BtnEditar"
        Me.BtnEditar.Size = New System.Drawing.Size(164, 44)
        Me.BtnEditar.TabIndex = 7
        Me.BtnEditar.Text = "Modificar"
        Me.BtnEditar.UseVisualStyleBackColor = False
        '
        'DgvTipo
        '
        Me.DgvTipo.BackgroundColor = System.Drawing.Color.White
        Me.DgvTipo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DgvTipo.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IdHaibtacion, Me.NoHabitacion, Me.Tipo, Me.Verificacion, Me.Precio, Me.Estacionamiento})
        Me.DgvTipo.Location = New System.Drawing.Point(35, 227)
        Me.DgvTipo.Name = "DgvTipo"
        Me.DgvTipo.Size = New System.Drawing.Size(540, 210)
        Me.DgvTipo.TabIndex = 2
        '
        'IdHaibtacion
        '
        Me.IdHaibtacion.DataPropertyName = "IdHabitacion"
        Me.IdHaibtacion.FillWeight = 200.0!
        Me.IdHaibtacion.HeaderText = "Id Habitacion"
        Me.IdHaibtacion.Name = "IdHaibtacion"
        Me.IdHaibtacion.Visible = False
        Me.IdHaibtacion.Width = 200
        '
        'NoHabitacion
        '
        Me.NoHabitacion.DataPropertyName = "NoHabitacion"
        Me.NoHabitacion.HeaderText = "Numero de Habitacion"
        Me.NoHabitacion.Name = "NoHabitacion"
        '
        'Tipo
        '
        Me.Tipo.DataPropertyName = "Tipo"
        Me.Tipo.HeaderText = "Tipo de Habitacion"
        Me.Tipo.Name = "Tipo"
        '
        'Verificacion
        '
        Me.Verificacion.DataPropertyName = "Verificacion"
        Me.Verificacion.HeaderText = "Verificacion"
        Me.Verificacion.Name = "Verificacion"
        '
        'Precio
        '
        Me.Precio.DataPropertyName = "Precio"
        Me.Precio.HeaderText = "Precio"
        Me.Precio.Name = "Precio"
        '
        'Estacionamiento
        '
        Me.Estacionamiento.DataPropertyName = "Estacionamiento"
        Me.Estacionamiento.HeaderText = "Estacionamiento"
        Me.Estacionamiento.Name = "Estacionamiento"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TxtNu)
        Me.GroupBox1.Controls.Add(Me.TxtPrecio)
        Me.GroupBox1.Controls.Add(Me.CmbSiNo)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.CmbVerificacion)
        Me.GroupBox1.Controls.Add(Me.CmbTipo)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(29, 44)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(656, 168)
        Me.GroupBox1.TabIndex = 4
        Me.GroupBox1.TabStop = False
        '
        'TxtNu
        '
        Me.TxtNu.Location = New System.Drawing.Point(193, 31)
        Me.TxtNu.Name = "TxtNu"
        Me.TxtNu.Size = New System.Drawing.Size(134, 20)
        Me.TxtNu.TabIndex = 27
        '
        'TxtPrecio
        '
        Me.TxtPrecio.Location = New System.Drawing.Point(506, 31)
        Me.TxtPrecio.Name = "TxtPrecio"
        Me.TxtPrecio.Size = New System.Drawing.Size(134, 20)
        Me.TxtPrecio.TabIndex = 4
        '
        'CmbSiNo
        '
        Me.CmbSiNo.FormattingEnabled = True
        Me.CmbSiNo.Items.AddRange(New Object() {"Si", "No"})
        Me.CmbSiNo.Location = New System.Drawing.Point(506, 79)
        Me.CmbSiNo.Name = "CmbSiNo"
        Me.CmbSiNo.Size = New System.Drawing.Size(134, 21)
        Me.CmbSiNo.TabIndex = 5
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(333, 78)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(165, 22)
        Me.Label6.TabIndex = 26
        Me.Label6.Text = "Estacionamiento"
        '
        'CmbVerificacion
        '
        Me.CmbVerificacion.BackColor = System.Drawing.Color.White
        Me.CmbVerificacion.FormattingEnabled = True
        Me.CmbVerificacion.Items.AddRange(New Object() {"Disponible ", "Ocupado "})
        Me.CmbVerificacion.Location = New System.Drawing.Point(193, 121)
        Me.CmbVerificacion.Name = "CmbVerificacion"
        Me.CmbVerificacion.Size = New System.Drawing.Size(134, 21)
        Me.CmbVerificacion.TabIndex = 3
        '
        'CmbTipo
        '
        Me.CmbTipo.BackColor = System.Drawing.Color.White
        Me.CmbTipo.FormattingEnabled = True
        Me.CmbTipo.Items.AddRange(New Object() {"Sencilla", "Doble"})
        Me.CmbTipo.Location = New System.Drawing.Point(193, 78)
        Me.CmbTipo.Name = "CmbTipo"
        Me.CmbTipo.Size = New System.Drawing.Size(134, 21)
        Me.CmbTipo.TabIndex = 2
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 120)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(119, 22)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Verificación"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(333, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(70, 22)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "Precio"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(8, 79)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(183, 22)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Tipo de Habitacion"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(170, 22)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "No. de habitacion"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Black", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(217, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(236, 30)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Agregar Habitacion"
        '
        'BtnCerrar
        '
        Me.BtnCerrar.BackColor = System.Drawing.Color.White
        Me.BtnCerrar.BackgroundImage = CType(resources.GetObject("BtnCerrar.BackgroundImage"), System.Drawing.Image)
        Me.BtnCerrar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.BtnCerrar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.BtnCerrar.Location = New System.Drawing.Point(634, 7)
        Me.BtnCerrar.Name = "BtnCerrar"
        Me.BtnCerrar.Size = New System.Drawing.Size(51, 34)
        Me.BtnCerrar.TabIndex = 34
        Me.BtnCerrar.UseVisualStyleBackColor = False
        '
        'FrmAgregarHabi
        '
        Me.AcceptButton = Me.BtnAgregar
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.CancelButton = Me.BtnCerrar
        Me.ClientSize = New System.Drawing.Size(704, 553)
        Me.Controls.Add(Me.BtnCerrar)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GbxHabilitar)
        Me.Controls.Add(Me.DgvTipo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "FrmAgregarHabi"
        Me.Text = "FrmAgregarHabi"
        Me.GbxHabilitar.ResumeLayout(False)
        CType(Me.DgvTipo, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GbxHabilitar As System.Windows.Forms.GroupBox
    Friend WithEvents BtnEliminar As System.Windows.Forms.Button
    Friend WithEvents BtnAgregar As System.Windows.Forms.Button
    Friend WithEvents BtnEditar As System.Windows.Forms.Button
    Friend WithEvents DgvTipo As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents CmbVerificacion As System.Windows.Forms.ComboBox
    Friend WithEvents CmbTipo As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents CmbSiNo As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnCerrar As System.Windows.Forms.Button
    Friend WithEvents TxtPrecio As System.Windows.Forms.TextBox
    Friend WithEvents IdHaibtacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NoHabitacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tipo As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Verificacion As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Precio As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Estacionamiento As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents TxtNu As System.Windows.Forms.TextBox
End Class
