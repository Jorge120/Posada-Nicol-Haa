﻿Imports MySql.Data.MySqlClient
Imports System.Text.RegularExpressions

Public Class FrmDatos

    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparece la hora automaticamente en el textbox
    'Funcionalidad: Agrega la hora actual(actualmente)
    'Fecha: 1/03/2017
    'Salida: *
    Private Sub FrmDatos_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Txtentrada.Text = Date.Now.ToString("hh:mm:ss")
        DgvTipo.DataSource = SQLSEL("Select * from habitacion").Tables("datos").DefaultView
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aprece la opcion de abrir formulario
    'Funcionalidad: Abre el formulario solicitado
    'Fecha: 1/03/2017
    'Salida: *
    Private Sub BtnHabita_Click(sender As Object, e As EventArgs)
        FrmTipo.Show()
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: llena las campos solicitados y las almacena
    'Funcionalidad: Modulo para insertar datos
    'Fecha: 1/03/2017
    'Salida: *
    Public Sub Agregardatos(evento As String)
        Dim insert As String
        insert = "INSERT INTO reservacion( NombreCompleto, Correo, Telefono, Fecha, DiasHospe, HoraEntrada, Habitacion, NoHabitacion, Precio, Total) values ('" & Txtnombrec.Text & "','" & Txtcorreo.Text & "', '" & Txttelefono.Text & "','" & Format(DtpFecha.Value, "yyyy-MM-dd") & "','" & TxtDias.Text & "','" & Txtentrada.Text & "','" & CmbTipo.Text & "','" & TxtNu.Text & "', '" & TxtPrecio.Text & "', '" & TxtRes.Text & "')"
        SQLIDU(insert)

    End Sub


    Public Function IsValidEmail(ByVal email As String) As Boolean
        If email = String.Empty Then Return False
        ' Compruebo si el formato de la dirección es correcto.
        Dim re As Regex = New Regex("^[\w._%-]+@[\w.-]+\.[a-zA-Z]{2,4}$")
        Dim m As Match = re.Match(email)
        Return (m.Captures.Count <> 0)
    End Function



    'Autor: Annet Anay Pool Can
    'Entrada: Aparecen datos insertados en el combobox
    'Funcionalidad: Escoge una opción 
    'Fecha: 5/03/2017
    'Salida: *



    'Autor: Annet Anay Pool Can
    'Entrada: Modulo para Limpiar las datos en los textbox
    'Funcionalidad: Limpia todos los datos escritos
    'Fecha: 3/03/2017
    'Salida: *
    Public Sub Limpiar()
        Txtnombrec.Clear()
        Txtcorreo.Clear()
        Txtentrada.Clear()
        Txttelefono.Clear()
        TxtDias.Clear()
        TxtNu.Clear()
        TxtPrecio.Clear()
        TxtRes.Clear()


    End Sub

    'Ver y componer
    'Autor: Annet Anay Pool Can
    'Entrada: Botón para insertar datos
    'Funcionalidad: Inserta los datos
    'Fecha: 5/03/2017
    'Salida: *
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Agregardatos(1)


        Dim bln As Boolean = IsValidEmail(Txtcorreo.Text)
        If bln = False Then
            MessageBox.Show("Incorrecto Verifique su correo ")

            Exit Sub
        End If

        MsgBox("Datos registrados")

        Limpiar()
    End Sub




    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub

    Private Sub BtnResul_Click(sender As Object, e As EventArgs) Handles BtnResul.Click
        Dim Sub_Total, Precio As Double
        Dim Cantidad As Integer

        Precio = TxtDias.Text
        Cantidad = TxtPrecio.Text

        Sub_Total = Precio * Cantidad
        TxtRes.Text = Sub_Total

    End Sub

    Private Sub CmbHa_SelectedIndexChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub DgvTipo_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvTipo.CellContentClick

    End Sub

    Private Sub Txtcorreo_TextChanged(sender As Object, e As EventArgs) Handles Txtcorreo.TextChanged
    End Sub

    Private Sub Txttelefono_KeyPress(ByVal sender As Object, _
                                ByVal e As KeyPressEventArgs) Handles Txttelefono.KeyPress

        Dim re As New Regex("[^0-9_\-\b]", RegexOptions.IgnoreCase)
        e.Handled = re.IsMatch(e.KeyChar)

    End Sub

    Private Sub Txttelefono_TextChanged(sender As Object, e As EventArgs) Handles Txttelefono.TextChanged

    End Sub


    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        FrmPreRegistro.Show()
    End Sub
End Class
