﻿Public Class FrmFiltroClientres

    Private Sub FrmFiltroClientres_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DGVHabitacion.DataSource = SQLSEL("Select NoHabitacion, Tipo, Verificacion from habitacion").Tables("datos").DefaultView
    End Sub

    Private Sub DGVCliente_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGVHabitacion.CellContentClick

    End Sub

    Private Sub DGVCliente_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles DGVHabitacion.CellEndEdit

    End Sub

    Private Sub TxtBuscar_TextChanged(sender As Object, e As EventArgs) Handles TxtBuscar.TextChanged
        FiltroHabitacion()
    End Sub


    'Componer
    'Autor: Annet Anay Pool Can
    'Entrada: Se agrega datos a la base de datos
    'Funcionalidad: Modulo para insertar datos en la base de datos
    'Fecha: 5/03/2017
    'Salida: *
    Public Sub FiltroHabitacion()


    End Sub

    Private Sub BtnModificar_Click(sender As Object, e As EventArgs) Handles BtnModificar.Click

    End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub
End Class