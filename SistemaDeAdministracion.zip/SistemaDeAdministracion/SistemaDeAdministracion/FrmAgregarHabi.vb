﻿Public Class FrmAgregarHabi


    Private Sub DgvTipo_CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DgvTipo.CellContentDoubleClick

    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: En el datagridview escoge a un cliente y lo elimina dandole un click
    'Funcionalidad: Elimina Clientes 
    'Fecha: 4/03/2017
    'Salida: *
    Private Sub BtnEliminar_Click(sender As Object, e As EventArgs) Handles BtnEliminar.Click
        Dim Eliminar As String

        'Se crea el comando elimiar  
        Eliminar = "Update habitacion SET Status=1" & _
           " Where IdHabitacion ='" & DgvTipo.Item(0, DgvTipo.CurrentCellAddress.Y).Value & "'"

        If MsgBox("Estas seguro de eliminar", vbYesNo + vbExclamation, "Estimado usuario") = vbYes Then
            'Se manda la el comando a la base de datos
            SQLIDU(Eliminar)
        End If
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen los datos en los combobox y en el datagridview
    'Funcionalidad: sirve para el filtreo datos en los combobox  
    'Fecha: 4/03/2017
    'Salida: *
    Private Sub FrmAgregarHabi_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'filtro(1)
        'Filtroverifi(1)
        'FiltroOpcion(1)
        'Llenar el DataGridView
        Buscar()

    End Sub

    Private Sub Buscar()
        DgvTipo.DataSource = SQLSEL("Select * from habitacion").Tables("datos").DefaultView
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen todos los datos que se hayan registrado
    'Funcionalidad: inserta datos
    'Fecha: 4/03/2017
    'Salida: *
    Private Sub BtnAgregar_Click(sender As Object, e As EventArgs) Handles BtnAgregar.Click

        Agregar(1)
        Buscar()
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen todos los que se hayan agregado
    'Funcionalidad: Modulo para insertar datos a la base de datos
    'Fecha: 4/03/2017
    'Salida: *
    Public Sub Agregar(evento As String)
        Dim insert As String = ""

        insert = "INSERT INTO habitacion(NoHabitacion, Tipo, Verificacion, Precio, Estacionamiento) values ('" & TxtNu.Text & "','" & CmbTipo.Text & "','" & CmbVerificacion.Text & "','" & TxtPrecio.Text & "','" & CmbSiNo.Text & "')"
        MsgBox("Usted A Agregado Una Habitacion")
        SQLIDU(insert)
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen datos solicitados en el combobox correspondiente
    'Funcionalidad: Modulo para el filtreo de datos en un combobox
    'Fecha: 4/03/2017
    'Salida: *
    'Public Sub Filtroverifi(Evento As String)
    '    completar(CmbVerificacion, "SELECT DISTINCT * FROM habitacion", "IdHabitacion", "Verificacion", "Verificacion")
    'End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen datos solicitados en el combobox correspondiente
    'Funcionalidad: Modulo para el filtreo de datos en un combobox
    'Fecha: 5/03/2017
    'Salida: *
    'Public Sub FiltroOpcion(Evento As String)
    '    completar(CmbSiNo, "SELECT DISTINCT * FROM habitacion", "IdHabitacion", "Estacionamiento", "Estacionamiento")
    'End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen datos solicitados en el combobox correspondiente
    'Funcionalidad: Modulo para el filtreo de datos en un combobox
    'Fecha: 5/03/2017
    'Salida: *
    'Public Sub filtro(evento As String)
    '    completar(CmbTipo, "SELECT DISTINCT * FROM habitacion", "IdHabitacion", "Tipo", "Tipo")
    'End Sub



    Private Sub BtnEditar_Click(sender As Object, e As EventArgs) Handles BtnEditar.Click
        'ActualizarHabitaciones()
        'MsgBox("Datos Actualizados")
    End Sub


    'Autor: Annet Anay Pool Can, shareny caamal llanes 
    'Entrada: Aparecen todos los  datos solicitados 
    'Funcionalidad: Modulo para hacer modificaciones a los datos
    'Fecha: 5/03/2017
    'Salida: *
    'Public Sub ActualizarHabitaciones()
    '    Dim Actualizar As String
    '    Actualizar = "UPDATE habitacion SET NoHabitacion='" & TxtNu.Text & "'," & _
    '                 " Tipo='" & CmbTipo.Text & "'," & _
    '                 " Verificacion='" & CmbVerificacion.Text & "'," & _
    '                 " Precio= '" & TxtPrecio.Text & "'," & _
    '                 " Estacionamiento='" & CmbSiNo.Text & "'" & _
    '                 " Where IdHabitacion='"
    '    SQLIDU(Actualizar)

    'End Sub

    Private Sub BtnCerrar_Click(sender As Object, e As EventArgs) Handles BtnCerrar.Click
        Me.Close()
    End Sub

End Class