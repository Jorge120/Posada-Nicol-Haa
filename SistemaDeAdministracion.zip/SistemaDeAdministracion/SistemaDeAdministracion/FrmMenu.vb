﻿Public Class FrmMenu

    Private Sub FrmMenu_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub CancelacionesToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CancelacionesToolStripMenuItem1.Click

    End Sub

    Private Sub CerrarSesiónToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CerrarSesiónToolStripMenuItem.Click
        Me.Close()
        frmBienvenida.Show()
    End Sub

    Private Sub ConfiguracionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConfiguracionesToolStripMenuItem.Click

    End Sub

    Private Sub AgregarHabitacionesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarHabitacionesToolStripMenuItem.Click
        FrmAgregarHabi.Show()
    End Sub

    Private Sub FiltreoDeClientesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FiltreoDeClientesToolStripMenuItem.Click
        FrmFiltroClientres.Show()
    End Sub


    'Autor: Annet Anay Pool Can
    'Entrada: Abre al formulario Solicitado
    'Funcionalidad: Abre al formulario frmNuevo, si el administrador lo solicita
    'Fecha: 5/03/2017
    'Salida: *
    Private Sub AgregarAdministradorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AgregarAdministradorToolStripMenuItem.Click
        FrmNuevo.Show()

    End Sub

    Private Sub CorteDeCajaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CorteDeCajaToolStripMenuItem.Click
        FrmCorteCaja.Show()
    End Sub

    Private Sub ModificaciojesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModificaciojesToolStripMenuItem.Click

    End Sub
End Class