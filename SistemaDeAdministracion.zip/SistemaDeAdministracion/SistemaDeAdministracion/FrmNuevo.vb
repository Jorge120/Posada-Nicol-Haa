﻿Public Class FrmNuevo
    Dim insert As String = ""
    Private Sub FrmNuevo_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

 
    Private Sub btnaceptar_Click(sender As Object, e As EventArgs) Handles btnaceptar.Click
        Agregar(1)
        Limpiar()
    End Sub
    Private Sub btncancelar_Click(sender As Object, e As EventArgs) Handles btncancelar.Click
        Me.Close()
    End Sub
    Public Sub Agregar(evento As String)
        insert = "INSERT INTO Login(IdLogin, Nombre, pass, Telefono) values ('" & TxtId.Text & "','" & TxtUsers.Text & "','" & Txtpasw.Text & "','" & Txttelefono.Text & "')"
        MsgBox("Usted se ha regisrado " & TxtUsers.Text)
        SQLIDU(insert)
    End Sub
    Public Sub Limpiar()
        TxtId.Clear()
        Txtpasw.Clear()
        TxtUsers.Clear()
        Txttelefono.Clear()
    End Sub
End Class